                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1762757
Hobsie's Parametric Leadscrew Upgrade by Hobsie is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

A while back I upgraded my P3Steel XL from threaded rods to leadscrews which I had to design some parts to do.

Initially, I designed these parts using OpenSCAD (files still available) but have more recently moved to designing the parts using OnShape (you can find the source along with my e3D titan carriage mount and cooling solution here: https://cad.onshape.com/documents/367e02ef7150ebe882159b94/w/2b2005ce9d7bf315204d75b4/e/114c7184cce1f865ad030b47)

***********
#####Changes:
8-May-2018
- I've uploaded my most recent version of these which I'm going to consider released and remove the WIP notice
- Development of the latest version is now exclusively done via OnShape
- I've reduced some of the chamfers to give the parts a cleaner look
- No changes to connection measurements (designed for P3Steel)
- Currently there is no mount for a end stop switch (because i've moved to sensorless homing using the excellent Duet Wifi board). I'll add that later

10-Feb-2017
- Added a hasBearingDivider boolean to turn the divider on and off more easily.
- Corrected some minor spelling mistakes in the scad file comments

16-Nov-2016
- Updated the XTensor to be a bit easier to print (especially with ABS)
- Added a pre-compiled XTensor stl file

07-Nov-2016
- Shortened the name of source files
- Made 18mm and 17mm STL files for convenience, scad file defaults to 18mm (refers to value of variable distanceBetweenLinearBearingAndLeadRod)

30-Oct-2016
- Fixed a minor bug that caused the motor centre to be off by 1mm in the Z axis (thanks to @emphacy for pointing that out!). Don't worry if you've already printed though, this is more of an aesthetic fix
- Also fixed a minor issue that caused the X-Stop mount to ever so slightly take up some screw void space

3-Oct-2016
- Fixed a bug in both the .scad and .stl files were the vertical linear rod centre and leadscrew centre were off by 0.5mm in the X axis. They should now be exactly 18mm from centre to centre with the default value.

9-Sep-2016
- First release

# Print Settings

Printer Brand: RepRap
Printer: Prusa P3Steel XL
Rafts: No
Supports: No
Resolution: 0.2
Infill: 20%

# How I Designed This

Most recent versions of the parts, including the V3's, were designed using OnShape. Older designed were done in OpenSCAD.

# Parametric Instructions & Changes

#####OpenSCAD files
I have uploaded some .stl files with default values but you can edit a bunch of parameters in the OpenSCAD source files to hopefully get what you're after.

You'll need OpenSCAD installed to edit the files, but once opened there's a bunch of comments detailing what parameters you may want to edit do. There's also some boolean options to turn on and off parts as well as an option for the 2 kinds of Lead rod bearings i've come across.

#####OnShape source
You can find the original OnShape design documents for these files here: https://cad.onshape.com/documents/367e02ef7150ebe882159b94/w/2b2005ce9d7bf315204d75b4/e/114c7184cce1f865ad030b47

## Alignment

The most requested change I've been asked about is Linear bearing/Lead rod alignment.

For alignment, in the .scad files you're going to want to take a look at the variables:

<code>distanceBetweenLinearBearingAndLeadRod = 18;</code>
<code>leadRodYaxisOffset = 0;</code>

These control the x/y offset of the rods from each other. If you've got some wild alignment differences in the Y axis, you may also need to take a look at changing:

<code>distanceBetweenSmoothRodAndLinearBearing = 15;</code>

OnShape: In on shape this is a little simpler. You alter the variables used in the sketches that build the parts or edit the sketches directly.

## Bearing type

The 2nd most requested feature is bearing type compatibility.

From what I've managed to gather, there are 2 major bearing types (stick some more examples in the comments if there's other common one's out there!)

1. A brass style bearing with 4 equally spaced holes for attaching (I have this type)
2. A plastic/delrin style bearing with 3 equally spaced holes for attaching

You can swap between the different bearing types by changing the following variable:

<code>leadRodBearingType = 0;</code>

A value of 0 gives the brass style, a value of 1 gives the plastic style.

OnShape: In on shape this is a little simpler. You alter the variables used in the sketches that build the parts or edit the sketches directly.

## Other optional features

The Motor mount part .scad file has 3 boolean values that you can set to add/remove features.

They are:

<code>hasZStopScrew = true;</code> // Setting this to true will add a section add a screw you can use to adjust z-stop min
<code>hasXStopMount = true;</code> // Setting this to true will add a mount for a X-min switch
<code>hasCableChainMount = true;</code> // Setting this to true will add 2 holes above the motor section to attach a cable chain mount

OnShape: This isn't an option for the OnShape source but could be edited in pretty easily

## Notes

- I tend to go a bit narrow with screw hole radius (I like to tap them to get a good thread)
- The .stl files were rendered with $fn=128 for a smoother finish on curves (files default to 32 because it's faster to render when its WIP)
- The previous parts I designed as a remix from other parts had the X smooth rods exposed a little, these new parts do away with that and enclose the smooth rods entirely, which should hopefully allow leadscrew bearings to sit on the part without needing to file an edge down!
- I initially designed these parts specifically for my P3Steel XL, however since they're now more parametric, they should work well with any Prusa i3 variant if you want to use Leadscrews